package com.r.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class RAccessibilityService : AccessibilityService() {
    companion object { var instance: RAccessibilityService? = null }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { instance = null; super.onDestroy() }

    fun clickByText(target: String): String {
        val root = rootInActiveWindow ?: return "Screen नहीं मिला"
        val query = target.trim()
        if (query.isBlank()) return "Click target नहीं मिला"
        val nodes = root.findAccessibilityNodeInfosByText(query)
        val node = nodes.firstOrNull { it.isVisibleToUser && it.isClickable } ?: nodes.firstOrNull { it.isVisibleToUser }
        if (node == null) return "'$query' नहीं मिला"
        val clicked = if (node.isClickable) node.performAction(AccessibilityNodeInfo.ACTION_CLICK) else clickCenter(node)
        return if (clicked) "'$query' click किया" else "'$query' click नहीं हुआ"
    }

    fun typeText(text: String): String {
        val root = rootInActiveWindow ?: return "Screen नहीं मिला"
        val node = findFocusedEditable(root) ?: return "Text field नहीं मिला"
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        return if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) "Text डाल दिया" else "Text नहीं डाला गया"
    }

    fun pressBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun pressHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)

    private fun findFocusedEditable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable && node.isFocused) return node
        for (i in 0 until node.childCount) node.getChild(i)?.let { child ->
            findFocusedEditable(child)?.let { return it }
        }
        return null
    }

    private fun clickCenter(node: AccessibilityNodeInfo): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
        val r = android.graphics.Rect()
        node.getBoundsInScreen(r)
        if (r.width() <= 0 || r.height() <= 0) return false
        val path = Path().apply { moveTo(r.centerX().toFloat(), r.centerY().toFloat()) }
        return dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 50)).build(), null, null)
    }
}
