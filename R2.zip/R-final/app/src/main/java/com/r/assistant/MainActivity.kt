package com.r.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var last: TextView
    private lateinit var input: EditText
    private lateinit var speech: SpeechManager
    private val engine by lazy { CommandEngine(this) }
    private val automation by lazy { AutomationEngine(this) }

    private val gold = Color.rgb(255, 205, 92)
    private val bg = Color.rgb(7, 8, 12)
    private val panel = Color.rgb(17, 19, 26)
    private val muted = Color.rgb(155, 160, 172)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        speech = SpeechManager(this, ::handleVoice, ::setStatus)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(18, 12, 18, 18)
        }

        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(4, 4, 4, 8)
        }
        val rMark = TextView(this).apply {
            text = "R"
            textSize = 30f
            setTextColor(gold)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        header.addView(rMark, LinearLayout.LayoutParams(52, 52))
        val headerText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        headerText.addView(TextView(this).apply {
            text = "R"
            textSize = 20f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        headerText.addView(TextView(this).apply {
            text = "PERSONAL VOICE ASSISTANT  •  R1"
            textSize = 10f
            letterSpacing = .08f
            setTextColor(muted)
        })
        header.addView(headerText, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(header)

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 4, 0, 12)
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = rounded(panel, 24f)
            setPadding(20, 22, 20, 22)
        }
        val orb = TextView(this).apply {
            text = "R"
            textSize = 58f
            setTextColor(gold)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(22, 23, 30))
                setStroke(2, gold)
            }
        }
        hero.addView(orb, LinearLayout.LayoutParams(126, 126).apply { bottomMargin = 14 })
        hero.addView(TextView(this).apply {
            text = "Ready"
            textSize = 21f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        })
        status = TextView(this).apply {
            text = "R तैयार है"
            textSize = 13f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(8, 8, 8, 0)
        }
        hero.addView(status)
        content.addView(hero, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 })

        val workflow = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(panel, 18f)
            setPadding(16, 14, 16, 14)
        }
        workflow.addView(TextView(this).apply {
            text = "AUTOMATION"
            textSize = 11f
            letterSpacing = .12f
            setTextColor(gold)
            typeface = Typeface.DEFAULT_BOLD
        })
        workflow.addView(TextView(this).apply {
            text = "एक command में कई steps चलाओ"
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 5, 0, 4)
        })
        workflow.addView(TextView(this).apply {
            text = "Chrome → Google Vids → Click → Type → Back"
            textSize = 12f
            setTextColor(muted)
        })
        content.addView(workflow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 })

        last = TextView(this).apply {
            text = "Last command: none"
            textSize = 12f
            setTextColor(muted)
            background = rounded(Color.rgb(12, 14, 19), 14f)
            setPadding(14, 12, 14, 12)
        }
        content.addView(last, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })

        input = EditText(this).apply {
            hint = "Command लिखें...  e.g. Chrome खोलो और Google Vids खोलो"
            setHintTextColor(Color.rgb(105, 110, 122))
            setTextColor(Color.WHITE)
            textSize = 14f
            setSingleLine(false)
            minLines = 3
            gravity = Gravity.TOP
            setPadding(16, 14, 16, 14)
            background = rounded(Color.rgb(20, 22, 29), 16f)
        }
        content.addView(input, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })

        val run = actionButton("RUN COMMAND", gold, Color.BLACK)
        run.setOnClickListener { handleVoice(input.text.toString()) }
        content.addView(run, buttonLp())

        val listen = actionButton("🎤  VOICE COMMAND", Color.rgb(29, 31, 40), Color.WHITE)
        listen.setOnClickListener { speech.start(); setStatus("🎤 सुन रहा हूँ...") }
        content.addView(listen, buttonLp())

        val stop = actionButton("STOP", Color.rgb(62, 27, 31), Color.rgb(255, 112, 120))
        stop.setOnClickListener { automation.stop(); speech.stop(); setStatus("R stopped") }
        content.addView(stop, buttonLp())

        val access = smallButton("Accessibility")
        access.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        val data = smallButton("File Analyze")
        data.setOnClickListener { openFile() }
        val code = smallButton("Generate Code")
        code.setOnClickListener {
            val p = input.text.toString().ifBlank { "Create an Android feature" }
            showResult(CodeGenerator.generate(p))
        }
        val tools = LinearLayout(this).apply { gravity = Gravity.CENTER }
        tools.addView(access, smallLp())
        tools.addView(data, smallLp())
        tools.addView(code, smallLp())
        content.addView(tools)

        content.addView(TextView(this).apply {
            text = "Examples\n• Chrome खोलो और Google Vids खोलो\n• Click New project\n• Type hello world\n• Back / Home\n• stop"
            textSize = 12f
            setTextColor(muted)
            setPadding(8, 16, 8, 8)
        })

        setContentView(root)
    }

    private fun handleVoice(text: String) {
        val command = text.trim()
        if (command.isBlank()) {
            setStatus("Command खाली है")
            return
        }
        last.text = "Last command: $command"
        setStatus("⚙ Processing...")
        val plan = automation.buildPlan(command)
        val isWorkflow = plan.size > 1 || Regex("""(?i)\\b(click|type|open|and|then)\\b|\\b(खोलो|खोलना|क्लिक|लिखो|डालो|और|फिर)\\b""").containsMatchIn(command)
        if (isWorkflow) {
            automation.execute(command, { step -> setStatus(step) }, { result ->
                showResult(result)
                speech.speak(result, resume = true)
            })
        } else {
            val result = engine.execute(command)
            showResult(result.reply)
            speech.speak(result.reply, resume = true)
        }
    }

    private fun setStatus(text: String) { if (::status.isInitialized) status.text = text }
    private fun showResult(text: String) { setStatus(text) }

    private fun openFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(i, 42)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42 && resultCode == RESULT_OK) data?.data?.let { showResult(DataAnalyzer.analyze(this, it)) }
    }

    private fun rounded(color: Int, radius: Float): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
    }

    private fun actionButton(text: String, backgroundColor: Int, textColor: Int) = Button(this).apply {
        this.text = text
        textSize = 14f
        setTextColor(textColor)
        typeface = Typeface.DEFAULT_BOLD
        isAllCaps = false
        background = rounded(backgroundColor, 16f)
        minHeight = 54
        stateListAnimator = null
    }

    private fun smallButton(text: String) = Button(this).apply {
        this.text = text
        textSize = 11f
        setTextColor(Color.WHITE)
        isAllCaps = false
        background = rounded(Color.rgb(25, 27, 35), 12f)
        minHeight = 44
        stateListAnimator = null
    }

    private fun buttonLp() = LinearLayout.LayoutParams(-1, 56).apply { bottomMargin = 8 }
    private fun smallLp() = LinearLayout.LayoutParams(0, 48, 1f).apply { leftMargin = 3; rightMargin = 3 }

    override fun onDestroy() {
        automation.stop()
        if (::speech.isInitialized) speech.shutdown()
        super.onDestroy()
    }
}
