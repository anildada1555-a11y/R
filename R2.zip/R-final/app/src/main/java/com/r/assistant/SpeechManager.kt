package com.r.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

class SpeechManager(
    context: Context,
    private val onText: (String) -> Unit,
    private val onStatus: (String) -> Unit
) : RecognitionListener, TextToSpeech.OnInitListener {
    private val app = context.applicationContext
    private val handler = Handler(Looper.getMainLooper())
    private val recognizer = if (SpeechRecognizer.isRecognitionAvailable(app)) SpeechRecognizer.createSpeechRecognizer(app) else null
    private val tts = TextToSpeech(app, this)
    private var continuous = false
    private var active = false
    private var ttsReady = false

    init { recognizer?.setRecognitionListener(this) }

    fun start() { continuous = true; startLater(150) }
    fun stop() { continuous = false; active = false; handler.removeCallbacksAndMessages(null); runCatching { recognizer?.cancel() } }

    private fun startLater(ms: Long) {
        handler.postDelayed({
            if (!continuous || active) return@postDelayed
            val r = recognizer ?: run { onStatus("Speech recognition उपलब्ध नहीं है"); return@postDelayed }
            active = true
            onStatus("🎤 सुन रहा हूँ...")
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            }
            runCatching { r.startListening(i) }.onFailure { active = false; if (continuous) startLater(900) }
        }, ms)
    }

    fun speak(text: String, resume: Boolean = true) {
        if (!ttsReady) { if (resume && continuous) startLater(500); return }
        val id = "r-${System.nanoTime()}"
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
        if (resume && continuous) handler.postDelayed({ startLater(700) }, (text.length * 55L).coerceIn(900, 3500))
    }

    override fun onInit(status: Int) { ttsReady = status == TextToSpeech.SUCCESS; if (ttsReady) tts.language = Locale("hi", "IN") }
    override fun onResults(results: Bundle?) { active = false; val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().trim(); if (text.isNotBlank()) onText(text) else if (continuous) startLater(500) }
    override fun onError(error: Int) { active = false; if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { continuous = false; onStatus("Microphone permission जरूरी है") } else if (continuous) startLater(600) }
    override fun onReadyForSpeech(params: Bundle?) { onStatus("बोलिए...") }
    override fun onBeginningOfSpeech() { onStatus("सुन रहा हूँ...") }
    override fun onEndOfSpeech() { onStatus("समझ रहा हूँ...") }
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onPartialResults(partialResults: Bundle?) {}
    override fun onEvent(eventType: Int, params: Bundle?) {}
    fun shutdown() { stop(); recognizer?.destroy(); tts.stop(); tts.shutdown() }
}
