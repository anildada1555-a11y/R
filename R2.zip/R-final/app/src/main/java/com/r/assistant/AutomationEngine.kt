package com.r.assistant

import android.content.Context
import android.os.Handler
import android.os.Looper

class AutomationEngine(private val context: Context) {
    data class Step(val label: String, val action: suspend () -> String)

    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var cancelled = false

    fun buildPlan(command: String): List<PlanStep> {
        val raw = command.trim()
        if (raw.isBlank()) return emptyList()
        val normalized = raw.replace(" फिर ", " और ", ignoreCase = true)
            .replace(" then ", " और ", ignoreCase = true)
        val parts = normalized.split(Regex("\\s+(?:और|and)\\s+|,\\s*|\\s*;\\s*"))
            .map { it.trim() }.filter { it.isNotBlank() }
        val steps = mutableListOf<PlanStep>()
        for (part in parts) {
            val p = part.lowercase()
            when {
                p.contains("stop") || p.contains("रुक") -> steps += PlanStep("STOP") { AutomationResult.STOP }
                p.contains("chrome") && (p.contains("खोल") || p.contains("open")) -> steps += PlanStep("Chrome खोलना") { launch("com.android.chrome", "Chrome") }
                p.contains("google vids") || p.contains("google video") -> steps += PlanStep("Google Vids खोलना") { url("https://vids.google.com/", "Google Vids") }
                p.contains("chatgpt") -> steps += PlanStep("ChatGPT खोलना") { url("https://chatgpt.com/", "ChatGPT") }
                p.contains("settings") || p.contains("सेटिंग") -> steps += PlanStep("Settings खोलना") { openSettings() }
                p.contains("back") || p.contains("पीछे") -> steps += PlanStep("Back") { RAccessibilityService.instance?.pressBack(); "Back किया" }
                p.contains("home") || p.contains("होम") -> steps += PlanStep("Home") { RAccessibilityService.instance?.pressHome(); "Home किया" }
                p.contains("click") || p.contains("क्लिक") || p.contains("dabao") || p.contains("दब") -> {
                    val target = part.substringAfter(Regex("(?i)click|क्लिक|dabao|दबाओ|दब"), "").trim().trim(':',' ')
                    steps += PlanStep("Click: ${target.ifBlank { "target" }}") { RAccessibilityService.instance?.clickByText(target) ?: "Accessibility ON करें" }
                }
                p.contains("type") || p.contains("लिख") || p.contains("डाल") -> {
                    val target = part.substringAfter(Regex("(?i)type|लिखो|लिख|डालो|डाल"), "").trim().trim(':',' ')
                    steps += PlanStep("Type text") { RAccessibilityService.instance?.typeText(target) ?: "Accessibility ON करें" }
                }
            }
        }
        return steps
    }

    fun stop() { cancelled = true; handler.removeCallbacksAndMessages(null) }

    fun execute(command: String, onStep: (String) -> Unit, onDone: (String) -> Unit) {
        cancelled = false
        val plan = buildPlan(command)
        if (plan.isEmpty()) { onDone("इस command के लिए automation step नहीं मिला") ; return }
        runStep(plan, 0, onStep, onDone)
    }

    private fun runStep(plan: List<PlanStep>, index: Int, onStep: (String) -> Unit, onDone: (String) -> Unit) {
        if (cancelled) { onDone("R stopped") ; return }
        if (index >= plan.size) { onDone("Workflow पूरा हुआ") ; return }
        val step = plan[index]
        onStep("▶ ${index + 1}/${plan.size}: ${step.name}")
        handler.postDelayed({
            val result = runCatching { step.run() }.getOrElse { "Step failed: ${it.message ?: "unknown error"}" }
            if (result == AutomationResult.STOP) { onDone("R stopped") ; return@postDelayed }
            onStep("✓ $result")
            handler.postDelayed({ runStep(plan, index + 1, onStep, onDone) }, 900)
        }, 350)
    }

    data class PlanStep(val name: String, val run: () -> String)

    private fun launch(pkg: String, name: String): String {
        val intent = context.packageManager.getLaunchIntentForPackage(pkg)
            ?: return "$name phone में नहीं मिला"
        context.startActivity(intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
        return "$name खोला"
    }

    private fun url(url: String, name: String): String {
        context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url)).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
        return "$name खोला"
    }

    private fun openSettings(): String {
        context.startActivity(android.content.Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Settings खोली"
    }

    private object AutomationResult { const val STOP = "__R_STOP__" }
}
