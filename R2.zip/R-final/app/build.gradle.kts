plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.r.assistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.r.assistant"
        minSdk = 23
        targetSdk = 35
        versionCode = 3
        versionName = "R2"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
