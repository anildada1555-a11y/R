# R • Automation

Phone-first Android automation app. This project is intentionally automation-only.

## Included
- Persistent workflows on the phone.
- Basic workflow step editor: WAIT, OPEN_URL, OPEN_APP, CLICK, TYPE, GENERATE, DOWNLOAD, VERIFY.
- Android Accessibility Service for UI actions.
- GitHub Releases based update checker/downloader.
- Settings for GitHub owner/repository and auto-update toggle.
- GitHub Actions release workflow with signing secrets.

## Auto-update security
Do **not** put a GitHub password or personal access token inside the APK. Public GitHub Releases do not need a password. Keep the signing keystore/password/alias only in GitHub Actions Secrets:
- `R_KEYSTORE_BASE64`
- `R_KEYSTORE_PASSWORD`
- `R_KEY_ALIAS`

Android will still show its normal package-install confirmation/permission when an APK update is installed. Silent installation is not available to an ordinary Android app.

## Important
This is a clean R1 automation base. Google Vids/Flow automation still depends on Chrome UI/accessibility selectors and may need site-specific selectors and verification. Do not treat it as a guaranteed one-click Vids/Flow API integration.
