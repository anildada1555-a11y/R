package com.r.automation

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object UpdateManager {
    private const val PREFS = "r_settings"
    private const val DEFAULT_OWNER = "anildada1555-a11y"
    private const val DEFAULT_REPO = "R"

    fun check(context: Context, onResult: (String, Boolean) -> Unit) {
        Thread {
            val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val owner = p.getString("owner", DEFAULT_OWNER).orEmpty()
            val repo = p.getString("repo", DEFAULT_REPO).orEmpty()
            val enabled = p.getBoolean("auto_update", true)
            if (!enabled || owner.isBlank() || repo.isBlank()) { onResult("Auto-update disabled", false); return@Thread }
            runCatching {
                val api = URL("https://api.github.com/repos/$owner/$repo/releases/latest")
                val c = api.openConnection() as HttpURLConnection
                c.requestMethod = "GET"; c.connectTimeout = 10000; c.readTimeout = 15000
                c.setRequestProperty("Accept", "application/vnd.github+json")
                val body = c.inputStream.bufferedReader().use { it.readText() }
                c.disconnect()
                val json = JSONObject(body)
                val tag = json.optString("tag_name", "")
                val asset = json.optJSONArray("assets")?.let { a ->
                    (0 until a.length()).map { a.getJSONObject(it) }.firstOrNull { it.optString("name").endsWith(".apk", true) }
                }
                val remoteCode = parseVersionCode(tag, json.optString("name", ""))
                val current = context.packageManager.getPackageInfo(context.packageName, 0).longVersionCode
                if (asset == null || remoteCode <= current) { onResult("R is up to date", false); return@Thread }
                val url = asset.optString("browser_download_url")
                val apk = File(context.cacheDir, "r-update.apk")
                val dl = URL(url).openConnection() as HttpURLConnection
                dl.connectTimeout = 10000; dl.readTimeout = 30000
                dl.inputStream.use { input -> apk.outputStream().use { out -> input.copyTo(out) } }
                dl.disconnect()
                val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", apk)
                val intent = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                context.startActivity(intent)
                onResult("Update downloaded. Android will ask for installation.", true)
            }.onFailure { onResult("Update check failed: ${it.message ?: "network error"}", false) }
        }
    }

    private fun parseVersionCode(tag: String, name: String): Long {
        val source = "$tag $name"
        val match = Regex("(?:R|r)?(\\d+)").find(source) ?: return -1
        return match.groupValues[1].toLongOrNull() ?: -1
    }
}
