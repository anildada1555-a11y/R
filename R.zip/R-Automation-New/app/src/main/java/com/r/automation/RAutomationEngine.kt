package com.r.automation

import android.content.Context
import android.content.Intent
import android.net.Uri

class RAutomationEngine(private val context: Context) {
    fun run(workflow: Workflow, log: (String) -> Unit) {
        if (!workflow.enabled) { log("Workflow disabled"); return }
        for ((index, step) in workflow.steps.withIndex()) {
            var success = false
            for (attempt in 0..step.retries.coerceIn(0, 5)) {
                log("Step ${index + 1}: ${step.type}")
                success = execute(step, log)
                if (success) break
                if (attempt < step.retries) log("Retry ${attempt + 1}")
            }
            if (!success) { log("Stopped at step ${index + 1}"); return }
            Thread.sleep(step.waitMs.coerceIn(0L, 60000L))
        }
        log("Workflow complete")
    }

    private fun execute(step: WorkflowStep, log: (String) -> Unit): Boolean = when (step.type.uppercase()) {
        "WAIT" -> true
        "OPEN_URL" -> runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(step.value)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true }.getOrDefault(false)
        "OPEN_APP" -> runCatching { val i = context.packageManager.getLaunchIntentForPackage(step.value) ?: return false; context.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true }.getOrDefault(false)
        "CLICK", "TYPE", "GENERATE", "DOWNLOAD", "VERIFY" -> { log("${step.type}: ${step.value}"); RAutomationAccessibilityService.executeStep(step) }
        else -> false
    }
}
