package com.r.automation

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object WorkflowStore {
    private const val PREFS = "r_store"
    private const val KEY = "workflows"
    private var loaded = false
    private val items = mutableListOf<Workflow>()

    private fun ensure(context: Context) {
        if (loaded) return
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val steps = mutableListOf<WorkflowStep>()
                val sa = o.optJSONArray("steps") ?: JSONArray()
                for (j in 0 until sa.length()) {
                    val s = sa.getJSONObject(j)
                    steps += WorkflowStep(
                        s.optString("type"), s.optString("value"), s.optLong("waitMs", 700),
                        s.optInt("retries", 1), s.optString("verify")
                    )
                }
                items += Workflow(o.optString("id"), o.optString("name", "Workflow"), o.optBoolean("enabled", true), steps)
            }
        }
        loaded = true
    }

    private fun save(context: Context) {
        val arr = JSONArray()
        items.forEach { w ->
            val o = JSONObject().put("id", w.id).put("name", w.name).put("enabled", w.enabled)
            val sa = JSONArray()
            w.steps.forEach { s ->
                sa.put(JSONObject().put("type", s.type).put("value", s.value).put("waitMs", s.waitMs).put("retries", s.retries).put("verify", s.verify))
            }
            o.put("steps", sa)
            arr.put(o)
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    fun all(context: Context): List<Workflow> { ensure(context); return items.toList() }
    fun add(context: Context, w: Workflow) { ensure(context); items += w; save(context) }
    fun delete(context: Context, id: String) { ensure(context); items.removeAll { it.id == id }; save(context) }
    fun replace(context: Context, w: Workflow) { ensure(context); val i = items.indexOfFirst { it.id == w.id }; if (i >= 0) items[i] = w else items += w; save(context) }
}
