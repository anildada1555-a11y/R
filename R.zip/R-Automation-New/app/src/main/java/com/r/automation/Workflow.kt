package com.r.automation

data class WorkflowStep(
    val type: String,
    val value: String = "",
    val waitMs: Long = 700L,
    val retries: Int = 1,
    val verify: String = ""
)

data class Workflow(
    val id: String,
    val name: String,
    val enabled: Boolean = true,
    val steps: List<WorkflowStep> = emptyList()
)
