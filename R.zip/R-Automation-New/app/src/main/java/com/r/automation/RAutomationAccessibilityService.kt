package com.r.automation

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class RAutomationAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile private var service: RAutomationAccessibilityService? = null
        fun executeStep(step: WorkflowStep): Boolean = service?.perform(step) ?: false
    }

    override fun onServiceConnected() { service = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun perform(step: WorkflowStep): Boolean {
        val root = rootInActiveWindow ?: return false
        return when (step.type.uppercase()) {
            "CLICK", "GENERATE", "DOWNLOAD" -> clickText(root, step.value)
            "TYPE" -> typeText(root, step.value)
            "VERIFY" -> root.findAccessibilityNodeInfosByText(step.value).isNotEmpty()
            else -> true
        }
    }

    private fun clickText(root: AccessibilityNodeInfo, text: String): Boolean {
        val node = root.findAccessibilityNodeInfosByText(text).firstOrNull() ?: return false
        return node.performAction(AccessibilityNodeInfo.ACTION_CLICK) ||
            node.parent?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
    }

    private fun typeText(root: AccessibilityNodeInfo, text: String): Boolean {
        val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = Bundle().apply {
            putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                text
            )
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    override fun onDestroy() {
        service = null
        super.onDestroy()
    }
}
