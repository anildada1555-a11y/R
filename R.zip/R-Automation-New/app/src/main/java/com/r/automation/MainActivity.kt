package com.r.automation

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private val bg = Color.rgb(11, 11, 15)
    private val white = Color.WHITE

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); render() }

    private fun render() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24,24,24,24); setBackgroundColor(bg) }
        root.addView(TextView(this).apply { text="R • Automation"; textSize=26f; setTextColor(white) })
        root.addView(TextView(this).apply { text="Phone automation workflows"; textSize=14f; setTextColor(Color.LTGRAY); setPadding(0,6,0,14) })
        val actions = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        actions.addView(Button(this).apply { text="+ Workflow"; setOnClickListener { createWorkflow() } }, LinearLayout.LayoutParams(0,-2,1f))
        actions.addView(Button(this).apply { text="Settings"; setOnClickListener { settings() } }, LinearLayout.LayoutParams(0,-2,1f))
        root.addView(actions)
        root.addView(Button(this).apply { text="Automation Access"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } })
        list = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        val scroll=ScrollView(this); scroll.addView(list); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f)); setContentView(root); refresh()
    }

    override fun onResume() { super.onResume(); if (::list.isInitialized) refresh() }

    private fun refresh() {
        list.removeAllViews()
        WorkflowStore.all(this).forEach { w ->
            val row=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0,12,0,12) }
            row.addView(TextView(this).apply { text="${w.name}  •  ${w.steps.size} steps"; textSize=17f; setTextColor(white) })
            val buttons=LinearLayout(this)
            buttons.addView(Button(this).apply { text="Run"; setOnClickListener { runWorkflow(w) } })
            buttons.addView(Button(this).apply { text="Edit"; setOnClickListener { editWorkflow(w) } })
            buttons.addView(Button(this).apply { text="Delete"; setOnClickListener { WorkflowStore.delete(this@MainActivity,w.id); refresh() } })
            row.addView(buttons); list.addView(row)
        }
    }

    private fun createWorkflow() {
        val input=EditText(this).apply { hint="Workflow name" }
        AlertDialog.Builder(this).setTitle("Create Workflow").setView(input).setPositiveButton("Create") { _,_ ->
            WorkflowStore.add(this, Workflow(System.currentTimeMillis().toString(), input.text.toString().ifBlank{"New Workflow"}, steps=listOf(WorkflowStep("WAIT",waitMs=500))))
            refresh()
        }.setNegativeButton("Cancel",null).show()
    }

    private fun editWorkflow(w: Workflow) {
        val name=EditText(this).apply { setText(w.name); hint="Name" }
        val info=TextView(this).apply { text="\nSteps are edited one at a time in the next editor."; setTextColor(Color.DKGRAY) }
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20,0,20,0); addView(name); addView(info) }
        AlertDialog.Builder(this).setTitle("Edit Workflow").setView(box).setPositiveButton("Save") { _,_ ->
            WorkflowStore.replace(this,w.copy(name=name.text.toString().ifBlank{w.name})); refresh()
        }.setNeutralButton("Edit Steps") { _,_ -> stepEditor(w) }.setNegativeButton("Cancel",null).show()
    }

    private fun stepEditor(w: Workflow) {
        val types=arrayOf("WAIT","OPEN_URL","OPEN_APP","CLICK","TYPE","GENERATE","DOWNLOAD","VERIFY")
        val rows=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        w.steps.forEachIndexed { index, step -> addStepRow(rows,index,step) }
        val add=Button(this).apply { text="+ Add Step"; setOnClickListener { addStepRow(rows, rows.childCount, WorkflowStep("WAIT",waitMs=700)) } }
        rows.addView(add)
        AlertDialog.Builder(this).setTitle("${w.name} • Steps").setView(ScrollView(this).apply { addView(rows) }).setPositiveButton("Save") { _,_ ->
            val steps=mutableListOf<WorkflowStep>(); for(i in 0 until rows.childCount-1){ val row=rows.getChildAt(i) as LinearLayout; val sp=row.getChildAt(0) as Spinner; val value=row.getChildAt(1) as EditText; val wait=row.getChildAt(2) as EditText; val retry=row.getChildAt(3) as EditText; steps += WorkflowStep(sp.selectedItem.toString(),value.text.toString(),wait.text.toString().toLongOrNull()?:700,retry.text.toString().toIntOrNull()?:1) }
            WorkflowStore.replace(this,w.copy(steps=steps)); refresh()
        }.setNegativeButton("Cancel",null).show()
    }

    private fun addStepRow(parent: LinearLayout,index:Int,step:WorkflowStep){
        val types=arrayOf("WAIT","OPEN_URL","OPEN_APP","CLICK","TYPE","GENERATE","DOWNLOAD","VERIFY")
        val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,8,0,8)}
        val sp=Spinner(this); sp.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,types); sp.setSelection(types.indexOf(step.type).coerceAtLeast(0))
        val value=EditText(this).apply{hint="Value / URL / text";setText(step.value)}
        val wait=EditText(this).apply{hint="Wait ms";setText(step.waitMs.toString());inputType=2}
        val retry=EditText(this).apply{hint="Retries";setText(step.retries.toString());inputType=2}
        row.addView(sp);row.addView(value);row.addView(wait);row.addView(retry);parent.addView(row,index.coerceAtMost(parent.childCount))
    }

    private fun runWorkflow(w:Workflow){
        Thread { RAutomationEngine(this).run(w){msg->runOnUiThread{Toast.makeText(this,msg,Toast.LENGTH_SHORT).show()}} }.start()
    }

    private fun settings(){
        val p=getSharedPreferences("r_settings",MODE_PRIVATE)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,0,20,0)}
        val owner=EditText(this).apply{hint="GitHub owner";setText(p.getString("owner","anildada1555-a11y"))}
        val repo=EditText(this).apply{hint="GitHub repository";setText(p.getString("repo","R"))}
        val auto=CheckBox(this).apply{text="Auto-update from GitHub Releases";isChecked=p.getBoolean("auto_update",true)}
        box.addView(owner);box.addView(repo);box.addView(auto)
        AlertDialog.Builder(this).setTitle("R Settings").setView(box)
            .setPositiveButton("Save"){_,_->p.edit().putString("owner",owner.text.toString().trim()).putString("repo",repo.text.toString().trim()).putBoolean("auto_update",auto.isChecked).apply();Toast.makeText(this,"Settings saved",Toast.LENGTH_SHORT).show()}
            .setNeutralButton("Check update"){_,_->UpdateManager.check(this){m,_->runOnUiThread{Toast.makeText(this,m,Toast.LENGTH_LONG).show()}}}
            .setNegativeButton("Cancel",null).show()
    }
}
