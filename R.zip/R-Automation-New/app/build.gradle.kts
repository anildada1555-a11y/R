plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace="com.r.automation"; compileSdk=35
    defaultConfig { applicationId="com.r.automation"; minSdk=26; targetSdk=35; versionCode=1; versionName="R1" }
}
dependencies { implementation("androidx.core:core-ktx:1.15.0"); implementation("androidx.appcompat:appcompat:1.7.0") }
