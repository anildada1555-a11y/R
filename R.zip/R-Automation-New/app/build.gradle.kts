plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val releaseVersionCode = (project.findProperty("versionCode") as String?)?.toIntOrNull() ?: 1
val keystoreFile = System.getenv("R_KEYSTORE_FILE")
val storePassword = System.getenv("R_KEYSTORE_PASSWORD")
val keyAlias = System.getenv("R_KEY_ALIAS")

android {
    namespace = "com.r.automation"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.r.automation"
        minSdk = 26
        targetSdk = 35
        versionCode = releaseVersionCode
        versionName = "R$releaseVersionCode"
    }

    signingConfigs {
        create("release") {
            if (!keystoreFile.isNullOrBlank()) {
                storeFile = file(keystoreFile)
                this.storePassword = storePassword
                this.keyAlias = keyAlias
                this.keyPassword = storePassword
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
