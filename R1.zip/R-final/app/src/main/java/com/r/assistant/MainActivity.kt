package com.r.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var last: TextView
    private lateinit var orb: ImageView
    private lateinit var input: EditText
    private lateinit var speech: SpeechManager
    private val engine by lazy { CommandEngine(this) }
    private val automation by lazy { AutomationEngine(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(5,5,7)
        window.navigationBarColor = Color.rgb(5,5,7)
        buildUi()
        speech = SpeechManager(this, ::handleVoice, ::setStatus)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(5,5,7)) }
        val bg = ImageView(this).apply { setImageResource(R.drawable.neon_ring); scaleType = ImageView.ScaleType.CENTER_CROP; alpha = 0.18f }
        root.addView(bg, FrameLayout.LayoutParams(-1,-1))
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28,24,28,36) }
        scroll.addView(box)
        root.addView(scroll, FrameLayout.LayoutParams(-1,-1))

        val title = TextView(this).apply { text = "R"; textSize = 42f; setTextColor(Color.rgb(255,215,106)); gravity = Gravity.CENTER; typeface = android.graphics.Typeface.DEFAULT_BOLD }
        box.addView(title, LinearLayout.LayoutParams(-1,60))
        val sub = TextView(this).apply { text = "PERSONAL ASSISTANT"; textSize = 12f; letterSpacing = .22f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER }
        box.addView(sub)

        orb = ImageView(this).apply { setImageResource(R.drawable.r_logo); scaleType = ImageView.ScaleType.CENTER_CROP; setPadding(18,18,18,18) }
        val orbLp = LinearLayout.LayoutParams(230,230).apply { gravity = Gravity.CENTER; topMargin = 20; bottomMargin = 18 }
        box.addView(orb, orbLp)

        status = label("R तैयार है", 16f, Color.WHITE); status.gravity = Gravity.CENTER
        box.addView(status, cardLp())
        last = label("Last command: none", 13f, Color.LTGRAY); last.gravity = Gravity.CENTER
        box.addView(last, cardLp())

        val listen = button("🎤  सुनना शुरू करें", Color.rgb(255,215,106), Color.BLACK)
        listen.setOnClickListener { speech.start(); setStatus("🎤 सुन रहा हूँ...") }
        box.addView(listen, btnLp())
        val stop = button("STOP", Color.rgb(255,93,103), Color.WHITE)
        stop.setOnClickListener { automation.stop(); speech.stop(); setStatus("R stopped") }
        box.addView(stop, btnLp())

        val access = button("⚙  Accessibility सेटिंग", Color.rgb(30,30,38), Color.WHITE)
        access.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        box.addView(access, btnLp())

        val data = button("📊  Data / File Analyze", Color.rgb(30,30,38), Color.WHITE)
        data.setOnClickListener { openFile() }
        box.addView(data, btnLp())

        val code = button("💻  Generate Code", Color.rgb(30,30,38), Color.WHITE)
        code.setOnClickListener { val p=input.text.toString().ifBlank { "Create an Android feature" }; showResult(CodeGenerator.generate(p)) }
        box.addView(code, btnLp())

        input = EditText(this).apply { hint = "Command / prompt लिखें..."; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); setTextSize(15f); setSingleLine(false); setPadding(18,18,18,18); setBackgroundColor(Color.rgb(20,20,26)) }
        box.addView(input, LinearLayout.LayoutParams(-1,100).apply { topMargin=18; bottomMargin=10 })
        val run = button("RUN COMMAND", Color.rgb(255,215,106), Color.BLACK)
        run.setOnClickListener { handleVoice(input.text.toString()) }
        box.addView(run, btnLp())

        val quick = label("Quick commands\n• Chrome खोलो\n• Google Vids खोलो\n• ChatGPT खोलो\n• Settings खोलो\n• Call +91XXXXXXXXXX\n• stop", 14f, Color.LTGRAY)
        quick.setPadding(8,20,8,0); box.addView(quick)
        setContentView(root)
    }

    private fun handleVoice(text: String) {
        last.text = "Last command: $text"
        setStatus("⚙ Command process हो रही है...")
        val plan = automation.buildPlan(text)
        val isWorkflow = plan.size > 1 || Regex("""(?i)\b(click|type|open|and|then)\b|\b(खोलो|खोलना|क्लिक|लिखो|डालो|और|फिर)\b""").containsMatchIn(text)
        if (isWorkflow) {
            automation.execute(text, { step -> setStatus(step) }, { result ->
                showResult(result)
                speech.speak(result, resume = true)
            })
        } else {
            val result = engine.execute(text)
            showResult(result.reply)
            speech.speak(result.reply, resume = true)
        }
    }
    private fun setStatus(text: String) { if (::status.isInitialized) status.text = text }
    private fun showResult(text: String) { setStatus(text) }

    private fun openFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }
        startActivityForResult(i, 42)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if (requestCode == 42 && resultCode == RESULT_OK) data?.data?.let { showResult(DataAnalyzer.analyze(this,it)) }
    }
    private fun label(t:String, s:Float, c:Int) = TextView(this).apply { text=t; textSize=s; setTextColor(c) }
    private fun cardLp() = LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin=6; bottomMargin=6 }
    private fun btnLp() = LinearLayout.LayoutParams(-1,58).apply { topMargin=6; bottomMargin=6 }
    private fun button(t:String, bg:Int, fg:Int) = Button(this).apply { text=t; textSize=15f; setTextColor(fg); setBackgroundColor(bg); isAllCaps=false }

    override fun onDestroy() { automation.stop(); if (::speech.isInitialized) speech.shutdown(); super.onDestroy() }
}
