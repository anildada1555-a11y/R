# R

Project name: **R**. A phone-first Android assistant foundation designed for voice commands, app launching, accessibility automation, code generation, and local text-file analysis.

## Included
- Voice recognition in Hindi (`hi-IN`) while the app is open
- Hindi text-to-speech
- Chrome / Google Vids / ChatGPT launching
- Dialer launching without placing calls automatically
- Accessibility service foundation for future UI automation
- Local text-file statistics and preview
- Simple offline code generator foundation
- Dark futuristic UI using the user-provided R logo and neon ring assets
- No API key embedded

## Important
Advanced AI generation, full-device automation, WhatsApp reading/sending, and true always-on background listening require additional Android permissions/services and/or an external AI provider. This project intentionally keeps those integration points explicit instead of pretending a button is magic.


## R1 Automation Engine
R1 adds a local workflow engine for multi-step commands. It can chain supported actions such as opening Chrome/Google Vids/ChatGPT/Settings, Back/Home, clicking visible accessibility nodes, and typing into a focused editable field. Each step is reported and the workflow stops on STOP.

Android Accessibility must be enabled for screen actions such as click/type/back/home.
