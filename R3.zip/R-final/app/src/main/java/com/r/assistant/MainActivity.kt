package com.r.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var last: TextView
    private lateinit var accessStatus: TextView
    private lateinit var input: EditText
    private lateinit var log: TextView
    private val engine by lazy { CommandEngine(this) }
    private val automation by lazy { AutomationEngine(this) }
    private val gold = Color.rgb(255, 205, 92)
    private val bg = Color.rgb(6, 7, 10)
    private val panel = Color.rgb(16, 18, 25)
    private val panel2 = Color.rgb(21, 23, 31)
    private val muted = Color.rgb(155, 160, 172)
    private val green = Color.rgb(95, 220, 145)
    private val red = Color.rgb(255, 105, 115)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg; window.navigationBarColor = bg
        buildUi()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10) else startBackgroundR()
    }
    override fun onResume() {
        super.onResume()
        uiListener = { kind, value -> runOnUiThread { if (kind == "COMMAND") { last.text = "Last command: $value"; appendLog("USER • $value") } else { setStatus(value); appendLog(value) } } }
        refreshAccessStatus()
    }
    override fun onPause() { uiListener = null; super.onPause() }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) { super.onRequestPermissionsResult(requestCode, permissions, grantResults); if (requestCode == 10 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startBackgroundR() else setStatus("Microphone permission जरूरी है") }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(bg) }
        val watermark = TextView(this).apply { text = "R"; textSize = 250f; alpha = 0.035f; setTextColor(gold); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER }
        root.addView(watermark, FrameLayout.LayoutParams(-1, -1))
        val main = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(10), dp(16), dp(16)) }
        root.addView(main, FrameLayout.LayoutParams(-1, -1))

        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(2), dp(2), dp(2), dp(10)) }
        header.addView(TextView(this).apply { text = "R"; textSize = 28f; setTextColor(gold); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(46), dp(46)))
        val hText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        hText.addView(TextView(this).apply { text = "R"; textSize = 21f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD })
        hText.addView(TextView(this).apply { text = "PERSONAL VOICE ASSISTANT  •  R3"; textSize = 10f; letterSpacing = .08f; setTextColor(muted) })
        header.addView(hText, LinearLayout.LayoutParams(0, -2, 1f)); main.addView(header)

        val scroll = ScrollView(this).apply { isFillViewport = true }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content); main.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val hero = card()
        hero.addView(TextView(this).apply { text = "R"; textSize = 52f; setTextColor(gold); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.rgb(20,21,28)); setStroke(dp(2), gold) } }, LinearLayout.LayoutParams(dp(112), dp(112)).apply { gravity = Gravity.CENTER; bottomMargin = dp(10) })
        hero.addView(TextView(this).apply { text = "R3 • Background Automation"; textSize = 19f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER })
        status = TextView(this).apply { text = "R तैयार है"; textSize = 13f; setTextColor(muted); gravity = Gravity.CENTER; setPadding(0, dp(7), 0, 0) }; hero.addView(status); content.addView(hero, marginBottom(12))

        val access = card(14); access.addView(label("SYSTEM ACCESS")); accessStatus = TextView(this).apply { textSize = 13f; setPadding(0, dp(6), 0, dp(8)) }; access.addView(accessStatus)
        access.addView(button("Accessibility Settings", panel2, Color.WHITE).apply { setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }, buttonLp()); content.addView(access, marginBottom(12))

        val automationCard = card(14); automationCard.addView(label("PRO AUTOMATION"))
        automationCard.addView(TextView(this).apply { text = "Background voice • multi-step • retry • verify • confirmation"; textSize = 13f; setTextColor(Color.WHITE); setPadding(0, dp(6), 0, dp(10)) })
        input = EditText(this).apply { hint = "Command लिखें…  उदाहरण: Chrome खोलो और search finance"; setHintTextColor(Color.rgb(105,110,122)); setTextColor(Color.WHITE); textSize = 14f; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE; minLines = 3; maxLines = 5; gravity = Gravity.TOP; setPadding(dp(14), dp(12), dp(14), dp(12)); background = rounded(panel2,16f) }
        automationCard.addView(input, marginBottom(9)); automationCard.addView(button("RUN AUTOMATION", gold, Color.BLACK).apply { setOnClickListener { sendCommand(input.text.toString()) } }, buttonLp())
        automationCard.addView(button("🎤  R BACKGROUND VOICE", panel2, Color.WHITE).apply { setOnClickListener { startBackgroundR() } }, buttonLp())
        automationCard.addView(button("STOP", Color.rgb(61,27,31), red).apply { setOnClickListener { automation.stop(); stopService(Intent(this@MainActivity, RBackgroundService::class.java)); setStatus("R stopped"); appendLog("STOP • background voice and workflow cancelled") } }, buttonLp())
        content.addView(automationCard, marginBottom(12))

        last = TextView(this).apply { text = "Last command: none"; textSize = 12f; setTextColor(muted); background = rounded(panel,14f); setPadding(dp(14),dp(12),dp(14),dp(12)) }; content.addView(last, marginBottom(10))
        val logCard = card(14); logCard.addView(label("LIVE EXECUTION LOG")); log = TextView(this).apply { text = "R ready"; textSize = 12f; setTextColor(muted); setPadding(0,dp(8),0,0) }; logCard.addView(log); content.addView(logCard, marginBottom(12))
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        tools.addView(button("File Analyze", panel2, Color.WHITE).apply { setOnClickListener { openFile() } }, smallLp())
        tools.addView(button("Generate Code", panel2, Color.WHITE).apply { setOnClickListener { showResult(CodeGenerator.generate(input.text.toString().ifBlank { "Create an Android feature" })) } }, smallLp())
        content.addView(tools, marginBottom(12))
        content.addView(TextView(this).apply { text = "R can continue after you leave the app.\n• Safe tasks run automatically\n• Message / call / payment / delete actions ask first\n• Say: हाँ or नहीं\n• STOP cancels the current workflow"; textSize = 12f; setTextColor(muted); setPadding(dp(8),dp(4),dp(8),dp(16)) })
        setContentView(root); refreshAccessStatus()
    }

    private fun startBackgroundR() { val intent = Intent(this, RBackgroundService::class.java).setAction(RBackgroundService.ACTION_START); if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent); setStatus("🎤 R background में सुन रहा है…") }
    private fun sendCommand(text: String) {
        val command = text.trim(); if (command.isBlank()) { setStatus("Command खाली है"); return }
        val plan = automation.buildPlan(command)
        if (plan.isNotEmpty()) automation.execute(command, { setStatus(it); appendLog(it) }, { result -> setStatus(result); appendLog(result) }) else { val result = engine.execute(command); showResult(result.reply) }
    }
    private fun refreshAccessStatus() { val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty().contains("com.r.assistant/com.r.assistant.RAccessibilityService"); accessStatus.text = if (enabled) "● Accessibility connected" else "○ Accessibility required for screen actions"; accessStatus.setTextColor(if (enabled) green else Color.rgb(255,190,100)) }
    private fun setStatus(text: String) { if (::status.isInitialized) status.text = text }
    private fun showResult(text: String) { setStatus(text) }
    private fun appendLog(text: String) { if (::log.isInitialized) log.text = "${text}\n\n${log.text}".take(2400) }
    private fun openFile() { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) },42) }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) { super.onActivityResult(requestCode,resultCode,data); if (requestCode == 42 && resultCode == RESULT_OK) data?.data?.let { showResult(DataAnalyzer.analyze(this,it)) } }
    private fun card(padding: Int = 18) = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(panel,20f); setPadding(dp(padding),dp(padding),dp(padding),dp(padding)) }
    private fun label(text: String) = TextView(this).apply { this.text=text; textSize=11f; letterSpacing=.12f; setTextColor(gold); typeface=Typeface.DEFAULT_BOLD }
    private fun button(text: String, backgroundColor: Int, textColor: Int) = Button(this).apply { this.text=text; textSize=13f; setTextColor(textColor); typeface=Typeface.DEFAULT_BOLD; isAllCaps=false; background=rounded(backgroundColor,15f); minHeight=dp(52); stateListAnimator=null; includeFontPadding=true; maxLines=2 }
    private fun buttonLp()=LinearLayout.LayoutParams(-1,dp(54)).apply{bottomMargin=dp(8)}
    private fun smallLp()=LinearLayout.LayoutParams(0,dp(50),1f).apply{leftMargin=dp(3);rightMargin=dp(3)}
    private fun marginBottom(v:Int)=LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(v)}
    private fun rounded(color:Int,radius:Float)=GradientDrawable().apply{setColor(color);cornerRadius=dp(radius.toInt()).toFloat()}
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    companion object { var uiListener: ((String,String)->Unit)? = null }
}
