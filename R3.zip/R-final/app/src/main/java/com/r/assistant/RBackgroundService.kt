package com.r.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder

class RBackgroundService : Service() {
    private lateinit var speech: SpeechManager
    private lateinit var automation: AutomationEngine
    private val engine by lazy { CommandEngine(this) }
    private var pendingConfirmation: String? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else startForeground(NOTIFICATION_ID, notification)
        automation = AutomationEngine(this)
        speech = SpeechManager(this, ::handleVoice, ::publishStatus)
        publishStatus("R तैयार है • background voice चालू")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            pendingConfirmation = null
            automation.stop()
            speech.stop()
            publishStatus("R stopped")
            stopSelf()
        } else speech.start()
        return START_STICKY
    }

    private fun handleVoice(raw: String) {
        val command = raw.trim()
        if (command.isBlank()) return
        publishCommand(command)
        pendingConfirmation?.let { pending ->
            when {
                isYes(command) -> { pendingConfirmation = null; publishStatus("हाँ • काम शुरू कर रहा हूँ"); runCommand(pending) }
                isNo(command) -> { pendingConfirmation = null; speech.speak("ठीक है, यह काम नहीं करूँगा।", true); publishStatus("काम रद्द किया") }
                else -> speech.speak("कृपया हाँ या नहीं बोलिए।", true)
            }
            return
        }
        if (isRisky(command)) {
            pendingConfirmation = command
            publishStatus("Confirmation चाहिए")
            speech.speak("यह काम message, call या कोई महत्वपूर्ण action कर सकता है। क्या मैं आगे बढ़ूँ? हाँ या नहीं बोलिए।", true)
            return
        }
        runCommand(command)
    }

    private fun runCommand(command: String) {
        val plan = automation.buildPlan(command)
        val workflowWords = Regex("(?i)\\b(click|tap|type|open|and|then|search|verify|swipe|wait)\\b|खोलो|खोलना|क्लिक|दबाओ|लिखो|टाइप|सर्च|जांच|ऊपर|नीचे|और|फिर").containsMatchIn(command)
        if (plan.isNotEmpty() && (plan.size > 1 || workflowWords)) {
            publishStatus("Planning • ${plan.size} steps")
            automation.execute(command, { publishStatus(it) }, { result -> publishStatus(result); speech.speak(result, true) })
        } else {
            val result = engine.execute(command)
            publishStatus(result.reply)
            speech.speak(result.reply, true)
        }
    }

    private fun isRisky(command: String): Boolean = Regex("(?i)\\b(send|call|delete|pay|payment|publish|post)\\b|भेज|कॉल|डिलीट|हटा|पेमेंट|पैसे|भुगतान|पोस्ट").containsMatchIn(command)
    private fun isYes(text: String): Boolean = Regex("(?i)^(हाँ|हा|yes|yes please|करो|कर दो|ठीक है|ok|okay)$").containsMatchIn(text.trim())
    private fun isNo(text: String): Boolean = Regex("(?i)^(नहीं|no|मत करो|रद्द|cancel|stop)$").containsMatchIn(text.trim())

    private fun publishStatus(text: String) { MainActivity.uiListener?.invoke("STATUS", text) }
    private fun publishCommand(text: String) { MainActivity.uiListener?.invoke("COMMAND", text) }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "R Voice Assistant", NotificationManager.IMPORTANCE_LOW)
            channel.description = "R background voice and automation"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("R is active")
            .setContentText("Voice listening and automation are running")
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        runCatching { automation.stop() }
        runCatching { speech.shutdown() }
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.r.assistant.action.START"
        const val ACTION_STOP = "com.r.assistant.action.STOP"
        private const val CHANNEL_ID = "r_voice"
        private const val NOTIFICATION_ID = 1001
    }
}
