package com.r.assistant

import android.content.Context
import android.net.Uri
import java.io.BufferedReader
import java.io.InputStreamReader

object DataAnalyzer {
    fun analyze(context: Context, uri: Uri): String {
        return runCatching {
            val text = context.contentResolver.openInputStream(uri)?.use { input -> BufferedReader(InputStreamReader(input)).readText() }.orEmpty()
            val lines = text.lines()
            val words = text.trim().split(Regex("\\s+")).count { it.isNotBlank() }
            val chars = text.length
            "Data analysis\n\nLines: ${lines.size}\nWords: $words\nCharacters: $chars\n\nPreview:\n${text.take(1200)}"
        }.getOrElse { "File analysis failed: ${it.message}" }
    }
}
