package com.r.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

class CommandEngine(private val context: Context) {
    data class Result(val handled: Boolean, val reply: String)

    fun execute(raw: String): Result {
        val cmd = raw.trim()
        val lower = cmd.lowercase()
        if (cmd.isBlank()) return Result(false, "Command नहीं मिली")

        if (lower == "stop" || lower.contains("emergency stop") || lower.contains("रुक जाओ")) {
            return Result(true, "R stopped")
        }
        if (lower.contains("chrome")) {
            return launchPackage("com.android.chrome", "Chrome")
        }
        if (lower.contains("google vids") || lower.contains("google video")) {
            return launchUrl("https://vids.google.com/", "Google Vids")
        }
        if (lower.contains("chatgpt")) {
            return launchUrl("https://chatgpt.com/", "ChatGPT")
        }
        if (lower.contains("settings")) {
            context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return Result(true, "Settings खोल रहा हूँ")
        }
        if (lower.startsWith("dial ") || lower.startsWith("call ") || lower.startsWith("कॉल ")) {
            val number = cmd.substringAfter(' ').trim().filter { it.isDigit() || it == '+' }
            if (number.isBlank()) return Result(true, "Number नहीं मिला")
            context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return Result(true, "Dialer खोल रहा हूँ")
        }
        if (lower.startsWith("open ")) {
            val target = cmd.substringAfter(' ').trim()
            if (target.startsWith("http")) return launchUrl(target, target)
            return Result(true, "मैं अभी $target के लिए app खोलने की कोशिश करूँगा")
        }
        return Result(false, "मैंने command सुनी: $cmd. इस command के लिए automation skill अभी जोड़ना बाकी है।")
    }

    private fun launchPackage(pkg: String, name: String): Result {
        val intent = context.packageManager.getLaunchIntentForPackage(pkg)
        return if (intent != null) {
            context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Result(true, "$name खोल रहा हूँ")
        } else Result(true, "$name इस phone पर नहीं मिला")
    }

    private fun launchUrl(url: String, name: String): Result {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return Result(true, "$name खोल रहा हूँ")
    }
}
