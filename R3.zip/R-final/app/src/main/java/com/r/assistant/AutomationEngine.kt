package com.r.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import kotlin.math.max

/**
 * Local, deterministic automation planner for R.
 * It executes only explicit device actions exposed by Android/Accessibility.
 */
class AutomationEngine(private val context: Context) {
    data class PlanStep(
        val name: String,
        val action: () -> ActionResult,
        val retries: Int = 1,
        val delayAfterMs: Long = 650L
    )

    data class ActionResult(val success: Boolean, val message: String)

    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var cancelled = false

    fun buildPlan(command: String): List<PlanStep> {
        val raw = command.trim()
        if (raw.isBlank()) return emptyList()

        val normalized = raw
            .replace(Regex("\\s+(फिर|then)\\s+", RegexOption.IGNORE_CASE), " और ")
            .replace(Regex("\\s+और\\s+", RegexOption.IGNORE_CASE), " || ")
            .replace(Regex("\\s+and\\s+", RegexOption.IGNORE_CASE), " || ")
            .replace(";", " || ")
            .replace(Regex("\\s*,\\s*"), " || ")

        val parts = normalized.split("||")
            .map { it.trim() }
            .filter { it.isNotBlank() }

        return parts.mapNotNull { part -> parsePart(part) }
    }

    private fun parsePart(part: String): PlanStep? {
        val p = part.lowercase()
        return when {
            p == "stop" || p.contains("रुक जाओ") || p == "रुको" ->
                PlanStep("STOP", { ActionResult(false, STOP) })

            p.contains("chrome") && (p.contains("open") || p.contains("खोल")) ->
                PlanStep("Chrome खोलना", { launch("com.android.chrome", "Chrome") })

            p.contains("whatsapp") && (p.contains("open") || p.contains("खोल")) ->
                PlanStep("WhatsApp खोलना", { launch("com.whatsapp", "WhatsApp") })

            (p.contains("youtube") || p.contains("यूट्यूब")) && (p.contains("open") || p.contains("खोल")) ->
                PlanStep("YouTube खोलना", { launch("com.google.android.youtube", "YouTube") })

            p.contains("google vids") || p.contains("google video") || p.contains("google vids") ->
                PlanStep("Google Vids खोलना", { openUrl("https://vids.google.com/", "Google Vids") })

            p.contains("chatgpt") ->
                PlanStep("ChatGPT खोलना", { openUrl("https://chatgpt.com/", "ChatGPT") })

            p.contains("settings") || p.contains("सेटिंग") ->
                PlanStep("Settings खोलना", { openSettings() })

            p.contains("files") || p.contains("file manager") || p.contains("फाइल") ->
                PlanStep("Files खोलना", { openFiles() })

            p.contains("phone") || p.contains("फोन") || p.contains("call") || p.contains("कॉल") ->
                PlanStep("Phone खोलना", { launch("com.android.dialer", "Phone") })

            p.contains("message") || p.contains("messages") || p.contains("मैसेज") ->
                PlanStep("Messages खोलना", { launch("com.google.android.apps.messaging", "Messages") })

            p.startsWith("search ") || p.startsWith("सर्च ") || p.startsWith("खोज ") -> {
                val query = extractAfter(part, listOf("search", "सर्च", "खोज"))
                if (query.isBlank()) null else PlanStep("Web search: $query", {
                    openUrl("https://www.google.com/search?q=${Uri.encode(query)}", "Google search")
                })
            }

            p.startsWith("open http") || p.startsWith("खोलो http") -> {
                val url = extractUrl(part)
                if (url.isBlank()) null else PlanStep("URL खोलना", { openUrl(url, "Website") })
            }

            p.contains("click") || p.contains("क्लिक") || p.contains("tap") || p.contains("दबाओ") || p.contains("दब") -> {
                val target = extractAfter(part, listOf("click", "क्लिक", "tap", "दबाओ", "दब"))
                if (target.isBlank()) null else PlanStep("Click: $target", {
                    RAccessibilityService.instance?.clickByText(target)?.let { ActionResult(!it.contains("नहीं") && !it.contains("failed", true), it) }
                        ?: ActionResult(false, "Accessibility ON करें")
                }, retries = 2)
            }

            p.contains("type") || p.contains("लिखो") || p.contains("लिख") || p.contains("डालो") || p.contains("टाइप") -> {
                val target = extractAfter(part, listOf("type", "लिखो", "लिख", "डालो", "डाल", "टाइप"))
                if (target.isBlank()) null else PlanStep("Type text", {
                    RAccessibilityService.instance?.typeText(target)?.let { ActionResult(!it.contains("नहीं") && !it.contains("failed", true), it) }
                        ?: ActionResult(false, "Accessibility ON करें")
                }, retries = 2)
            }

            p.contains("back") || p.contains("पीछे") ->
                PlanStep("Back", {
                    val ok = RAccessibilityService.instance?.pressBack() == true
                    ActionResult(ok, if (ok) "Back किया" else "Back नहीं हुआ")
                })

            p.contains("home") || p.contains("होम") ->
                PlanStep("Home", {
                    val ok = RAccessibilityService.instance?.pressHome() == true
                    ActionResult(ok, if (ok) "Home किया" else "Home नहीं हुआ")
                })

            p.contains("swipe up") || p.contains("ऊपर स्वाइप") || p.contains("ऊपर स्क्रोल") ->
                PlanStep("Swipe up", {
                    val ok = RAccessibilityService.instance?.swipeUp() == true
                    ActionResult(ok, if (ok) "Swipe up किया" else "Swipe up नहीं हुआ")
                })

            p.contains("swipe down") || p.contains("नीचे स्वाइप") || p.contains("नीचे स्क्रोल") ->
                PlanStep("Swipe down", {
                    val ok = RAccessibilityService.instance?.swipeDown() == true
                    ActionResult(ok, if (ok) "Swipe down किया" else "Swipe down नहीं हुआ")
                })

            p.startsWith("wait ") || p.startsWith("रुको ") || p.startsWith("इंतजार ") -> {
                val seconds = Regex("\\d+").find(part)?.value?.toLongOrNull()?.coerceIn(1, 30) ?: 1L
                PlanStep("Wait ${seconds}s", { ActionResult(true, "${seconds}s wait पूरा") }, delayAfterMs = seconds * 1000L)
            }

            p.startsWith("verify ") || p.startsWith("check ") || p.startsWith("देखो ") || p.startsWith("जांच ") -> {
                val target = extractAfter(part, listOf("verify", "check", "देखो", "जांच"))
                if (target.isBlank()) null else PlanStep("Verify: $target", {
                    RAccessibilityService.instance?.verifyVisibleText(target)?.let { ActionResult(it, if (it) "'$target' मिला" else "'$target' नहीं मिला") }
                        ?: ActionResult(false, "Accessibility ON करें")
                })
            }

            else -> null
        }
    }

    fun stop() {
        cancelled = true
        handler.removeCallbacksAndMessages(null)
    }

    fun execute(command: String, onStep: (String) -> Unit, onDone: (String) -> Unit) {
        cancelled = false
        val plan = buildPlan(command)
        if (plan.isEmpty()) {
            onDone("इस command के लिए automation step नहीं मिला")
            return
        }
        runStep(plan, 0, onStep, onDone)
    }

    private fun runStep(
        plan: List<PlanStep>,
        index: Int,
        onStep: (String) -> Unit,
        onDone: (String) -> Unit
    ) {
        if (cancelled) { onDone("R stopped"); return }
        if (index >= plan.size) { onDone("✓ Workflow पूरा हुआ (${plan.size} steps)"); return }

        val step = plan[index]
        onStep("STEP ${index + 1}/${plan.size}  •  ${step.name}")
        handler.postDelayed({ runAttempt(plan, index, step, 0, onStep, onDone) }, 250)
    }

    private fun runAttempt(
        plan: List<PlanStep>,
        index: Int,
        step: PlanStep,
        attempt: Int,
        onStep: (String) -> Unit,
        onDone: (String) -> Unit
    ) {
        if (cancelled) { onDone("R stopped"); return }
        val result = runCatching { step.action() }.getOrElse { ActionResult(false, "Error: ${it.message ?: "unknown"}") }

        if (!result.success && result.message != STOP && attempt < step.retries) {
            onStep("↻ Retry ${attempt + 1}/${step.retries}: ${step.name}")
            handler.postDelayed({ runAttempt(plan, index, step, attempt + 1, onStep, onDone) }, 700)
            return
        }

        if (result.message == STOP) { onDone("R stopped"); return }
        onStep(if (result.success) "✓ ${result.message}" else "✗ ${result.message}")
        if (!result.success) { onDone("Workflow stopped at step ${index + 1}: ${result.message}"); return }

        handler.postDelayed({ runStep(plan, index + 1, onStep, onDone) }, max(250L, step.delayAfterMs))
    }

    private fun launch(pkg: String, name: String): ActionResult {
        val intent = context.packageManager.getLaunchIntentForPackage(pkg)
            ?: return ActionResult(false, "$name phone में नहीं मिला")
        context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return ActionResult(true, "$name खोला")
    }

    private fun openUrl(url: String, name: String): ActionResult {
        return runCatching {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            ActionResult(true, "$name खोला")
        }.getOrElse { ActionResult(false, "$name नहीं खुला") }
    }

    private fun openSettings(): ActionResult {
        context.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return ActionResult(true, "Settings खोली")
    }

    private fun openFiles(): ActionResult {
        return runCatching {
            context.startActivity(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "*/*"
                addCategory(Intent.CATEGORY_OPENABLE)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
            ActionResult(true, "Files खोले")
        }.getOrElse { ActionResult(false, "Files नहीं खुले") }
    }

    private fun extractAfter(text: String, keywords: List<String>): String {
        val lower = text.lowercase()
        val matches = keywords.mapNotNull { key ->
            val index = lower.indexOf(key.lowercase())
            if (index >= 0) index to key.length else null
        }
        val match = matches.minByOrNull { it.first } ?: return ""
        return text.substring(match.first + match.second)
            .trim()
            .trim(':', '-', ' ')
    }

    private fun extractUrl(text: String): String =
        Regex("https?://\\S+", RegexOption.IGNORE_CASE).find(text)?.value.orEmpty()

    companion object { private const val STOP = "__R_STOP__" }
}
