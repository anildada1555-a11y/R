package com.r.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class RAccessibilityService : AccessibilityService() {
    companion object { var instance: RAccessibilityService? = null }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { instance = null; super.onDestroy() }

    fun clickByText(target: String): String {
        val root = rootInActiveWindow ?: return "Screen नहीं मिला"
        val query = target.trim()
        if (query.isBlank()) return "Click target खाली है"
        val candidates = mutableListOf<AccessibilityNodeInfo>()
        candidates += root.findAccessibilityNodeInfosByText(query)
        collectNodes(root, candidates) { node ->
            val text = node.text?.toString().orEmpty()
            val desc = node.contentDescription?.toString().orEmpty()
            text.equals(query, true) || desc.equals(query, true) ||
                text.contains(query, true) || desc.contains(query, true)
        }
        val node = candidates.firstOrNull { it.isVisibleToUser && it.isClickable }
            ?: candidates.firstOrNull { it.isVisibleToUser }
            ?: return "'$query' नहीं मिला"
        val clicked = if (node.isClickable) node.performAction(AccessibilityNodeInfo.ACTION_CLICK) else clickCenter(node)
        return if (clicked) "'$query' click किया" else "'$query' click नहीं हुआ"
    }

    fun typeText(text: String): String {
        val root = rootInActiveWindow ?: return "Screen नहीं मिला"
        val node = findFocusedEditable(root) ?: findFirstEditable(root) ?: return "Text field नहीं मिला"
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) "Text डाल दिया" else "Text नहीं डाला गया"
    }

    fun verifyVisibleText(target: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val q = target.trim()
        if (q.isBlank()) return false
        return root.findAccessibilityNodeInfosByText(q).any { it.isVisibleToUser } ||
            findMatchingNode(root, q)
    }

    fun pressBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun pressHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)

    fun swipeUp(): Boolean = swipe(0.5f, 0.78f, 0.5f, 0.25f)
    fun swipeDown(): Boolean = swipe(0.5f, 0.25f, 0.5f, 0.78f)

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
        val width = resources.displayMetrics.widthPixels.toFloat()
        val height = resources.displayMetrics.heightPixels.toFloat()
        val path = Path().apply {
            moveTo(width * x1, height * y1)
            lineTo(width * x2, height * y2)
        }
        return dispatchGesture(
            GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 450))
                .build(), null, null
        )
    }

    private fun clickCenter(node: AccessibilityNodeInfo): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
        val r = Rect()
        node.getBoundsInScreen(r)
        if (r.width() <= 0 || r.height() <= 0) return false
        val path = Path().apply { moveTo(r.centerX().toFloat(), r.centerY().toFloat()) }
        return dispatchGesture(
            GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
                .build(), null, null
        )
    }

    private fun findFocusedEditable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable && node.isFocused) return node
        for (i in 0 until node.childCount) node.getChild(i)?.let { child ->
            findFocusedEditable(child)?.let { return it }
        }
        return null
    }

    private fun findFirstEditable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable && node.isVisibleToUser) return node
        for (i in 0 until node.childCount) node.getChild(i)?.let { child ->
            findFirstEditable(child)?.let { return it }
        }
        return null
    }

    private fun findMatchingNode(node: AccessibilityNodeInfo, query: String): Boolean {
        val text = node.text?.toString().orEmpty()
        val desc = node.contentDescription?.toString().orEmpty()
        if (node.isVisibleToUser && (text.contains(query, true) || desc.contains(query, true))) return true
        for (i in 0 until node.childCount) node.getChild(i)?.let { child ->
            if (findMatchingNode(child, query)) return true
        }
        return false
    }

    private fun collectNodes(
        node: AccessibilityNodeInfo,
        out: MutableList<AccessibilityNodeInfo>,
        predicate: (AccessibilityNodeInfo) -> Boolean
    ) {
        if (predicate(node)) out += node
        for (i in 0 until node.childCount) node.getChild(i)?.let { collectNodes(it, out, predicate) }
    }
}
