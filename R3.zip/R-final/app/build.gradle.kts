plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.r.assistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.r.assistant"
        minSdk = 23
        targetSdk = 35
        versionCode = 5
        versionName = "R3"
    }

    signingConfigs {
        create("release") {
            val keystorePath = System.getenv("R_KEYSTORE_PATH")
            val storePasswordEnv = System.getenv("R_KEYSTORE_PASSWORD")
            val keyAliasEnv = System.getenv("R_KEY_ALIAS")
            val keyPasswordEnv = System.getenv("R_KEY_PASSWORD")

            if (!keystorePath.isNullOrBlank() &&
                !storePasswordEnv.isNullOrBlank() &&
                !keyAliasEnv.isNullOrBlank() &&
                !keyPasswordEnv.isNullOrBlank()
            ) {
                storeFile = file(keystorePath)
                storePassword = storePasswordEnv
                keyAlias = keyAliasEnv
                keyPassword = keyPasswordEnv
            }
        }
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
