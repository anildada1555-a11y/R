# R — R3 Professional Voice + Background Automation

R remains the assistant name. R3 is the project version.

## R3
- Hindi/Hinglish continuous voice recognition
- Tuned smooth device TTS voice
- Foreground microphone service so R can continue after leaving the app
- Multi-step Accessibility automation with retry/verification
- Voice confirmation for risky actions: message/send, call, delete, payment, publish/post
- Spoken workflow completion and status
- Clean dark UI with a subtle R watermark background

Android shows a foreground-service notification while microphone/background automation is active. Accessibility must be enabled for screen actions.
